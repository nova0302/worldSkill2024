/*
 * shift_reg.h
 *
 *  Created on: Dec 27, 2023
 *      Author: sooho
 */

#ifndef INC_SHIFT_REG_H_
#define INC_SHIFT_REG_H_

void shift_reg_init();
void shift_reg_update();
void writeChar(uint16_t c);
void writeCharR(uint16_t c);

#endif /* INC_SHIFT_REG_H_ */
