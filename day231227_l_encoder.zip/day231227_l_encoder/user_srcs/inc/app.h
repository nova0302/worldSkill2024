/*
 * app.h
 *
 *  Created on: Dec 27, 2023
 *      Author: sooho
 */

#ifndef INC_APP_H_
#define INC_APP_H_

void appSetup();
void appLoop();


#endif /* INC_APP_H_ */
