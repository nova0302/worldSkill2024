/*
 * demux.h
 *
 *  Created on: Dec 27, 2023
 *      Author: sooho
 */

#ifndef INC_DEMUX_H_
#define INC_DEMUX_H_

void demux_init();
void demux_update();


#endif /* INC_DEMUX_H_ */
