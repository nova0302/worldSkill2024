#ifndef __DELAY_H
#define __DELAY_H

#include "main.h"

void Delay_us(uint32_t us);

#endif
